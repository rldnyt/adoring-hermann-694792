channel_name=[]  # type: List[Any]
channel_id=[]  # type: List[Any]
channel_type=[]  # type: List[Any]
channel_info=[]  # type: List[Any]

#모듈 인포트 아래에 입력하세요!

all_channels = app.get_all_channels()

for channel1 in all_channels:
    channel_type.append(str(channel1.type)) #채널타입을 저장함
    channel_info.append(channel1) #채널의 이름들을 저장함

for i in range(len(channel_info)): #채널의 갯수만큼 반복합니다
    if channel_info[i].name == "찾을 채널이름": #(찾을 채널이름)을 가진 채널들을 타게팅합니다
        await message.channel.send(str(channel_info[i].id)) #그 타게팅한 채널들의 id을 저장합니다.