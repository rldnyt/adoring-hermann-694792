client.on("ready", () => {
  console.log("주인님! 반갑다!");
    console.log(`Login ${client.user.username}\n----------------------------`)
  const botgame = [ `${client.guilds.size}개의 서버 | ${client.users.size}명의 유저 | ${client.channels.size}개의 채팅 채널과 함께하고 있어요!`, '이 메세지는 10초마다 랜덤으로 바뀌어요! ', '`루연아 도움` 입력']

  setInterval(() => {
    let activity = botgame[Math.floor(Math.random() * botgame.length)]
    client.user.setActivity(activity, { type: "PLAYING" })
  }, 10000)
    //LISTENING : 듣는중
    //PLAYING : 하는중
    //STREAMING : 일반
    //WATCHING : 보는중
});