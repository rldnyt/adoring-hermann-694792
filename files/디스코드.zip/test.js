const Discord = require("discord.js");
const client = new Discord.Client();
const fs = require('fs');
const token = "NjYwNzExOTMxMjU4MzM5MzU4.XnQRsw.y26L4Wu09RCfvQenf1Zrrz3CAlc";
const money = require("./money.json");

client.on("ready", () => {
	//그깟 대충..
  console.log("주인님! 반갑다!");
});

client.on("message", message => {
	if (message.content === "돈받기") { //돈 받기라고 입력했을때
      if (!money[message.author.id]) {
        money[message.author.id] = {
          money: 0
        };
      }

      let moneyAmt = Math.floor(Math.random() * 100) + 1; //랜덤으로 100까지의 수중 랜덤으로 골라 추가한다.
      let baseAmt = moneyAmt; //baseAnt 는 MoneyAmt 와 같은것이다(?)

      if (moneyAmt === baseAmt) { //moneyAmt 와 baseAmt 가 똑같을때
        money[message.author.id] = {
          money: money[message.author.id].money + moneyAmt //json 에 id 와 money 라는 갑에 monetAmt 으로 지정한다.
        };

        fs.writeFile("./money.json", JSON.stringify(money), err => { //json 파일을 저장한다, 에러가 나면 콘솔로 출력
          if (err) console.log(err); //오류 콘솔 출력
        });
        console.log(money); //추가됀 json(추가됀 금액)

        let umoney = money[message.author.id].money;

        const embed = new Discord.RichEmbed() //임베드
          .setTitle("돈 지급 완료!")
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setTimestamp()
          .setColor(0xffff00)
          .setThumbnail(message.author.displayAvatarURL)
          .addField("지급된 돈(원)", `${moneyAmt}`)
          .addField("보유 금액(원)", `${umoney}`);
        message.channel.send(embed); //임베드 출력
      }
    } else if (message.content === "돈") { //돈이라고 채팅했을때
      if (message.content === "돈") {
        if (!money[message.author.id]) {
          money[message.author.id] = {
            money: 0
          };
        }

        let umoney = money[message.author.id].money;

        const embed = new Discord.RichEmbed() //임베드
          .setTitle(`${message.author.username}님의 돈`)
          .setFooter(message.author.username, message.author.displayAvatarURL)
          .setThumbnail(message.author.displayAvatarURL)
          .setTimestamp()
          .setColor(0xffff00)
          .addField("현재 돈(원)", `${umoney}`);
        message.channel.send(embed); //임베드 출력
      }
    }
});

client.login(token); 