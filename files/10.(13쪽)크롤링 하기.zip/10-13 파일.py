html = urlopen("(크롤링할 사이트 링크)").read()  # 내용 불러옴
soup = BeautifulSoup(html, "html.parser")
myUrls = soup.select('크롤링할 태그')
dnjs = 0
for j in myUrls:
    fdfe.append(j.text) #크롤링 정보을 사용/저장할곳