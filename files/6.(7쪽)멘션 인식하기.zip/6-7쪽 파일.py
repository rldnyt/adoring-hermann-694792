    if message.content.startswith("!테스트"):
        rottn = message.content[8:26]
        await message.channel.send(rottn)