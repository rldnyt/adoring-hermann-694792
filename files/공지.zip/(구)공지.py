import discord
from discord.ext import commands
import datetime

app = commands.Bot(command_prefix='')
tokn = '토큰'

botc=[]  # type: List[Any]

@commands.has_permissions(administrator=True)
@app.command(name="공지설정", pass_context=True)
async def 공지설정(ctx):
    global botc
    channel_id = ctx.message.content[11:29]
    botc.append(int(channel_id))
    await ctx.channel.send("봇공지 알림 채널이 <#{}> 으로 설정이 돼었습니다.".format(botc))

@app.event
@asyncio.coroutine
async def on_message(message):
    global botc
    await app.process_commands(message)

    if message.content.startswith("(공지 명령어)"):
        msg = message.content[8:] #인식 글 포함하여 글자수후 +1한후 [(여기):]에 넣어주세요
        now = datetime.datetime.now()
        if (message.author.id ==) :#"== "다음에 공지사용을 허용할 사람에 id 입력
            for i in range(len(botc), 0, -1):
                embed = discord.Embed(
                    description="공지" "\n\n" + msg,
                    colour=discord.Colour.red()
                )
                embed.set_footer(text=str(message.author) + " | " + str(now.year) + "년 " + str(now.month) + "월 " + str(now.day) + "일 | " + str(now.hour) + ":" + str(now.minute) + ":" + str(now.second),icon_url=message.author.avatar_url)
                channel = app.get_channel(botc[i - 1])
                await channel.send(embed=embed)
                await message.channel.send("공지가 완료돼었습니다.")
        else:
            await message.channel.send("당신은 개발자 권한이 없습니다.")

app.run(tokn)