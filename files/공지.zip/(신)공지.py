
channel_name=[]  # type: List[Any]
channel_id=[]  # type: List[Any]
channel_type=[]  # type: List[Any]
channel_info=[]  # type: List[Any]
botc=[]  # type: List[Any]
ok = 0  # type: int

@commands.has_permissions(manage_messages=True)
@app.command(name="봇공지채널생성", pass_context=True)
async def 봇공지채널생성(ctx):
    await ctx.channel.send("")#공지채널이 만들어지면 알릴네용
    overwrites = {
        ctx.guild.default_role: discord.PermissionOverwrite(read_messages=True, send_messages=False),
        ctx.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
    }
    await ctx.guild.create_text_channel('채널이름', reason="체널만든이유", overwrites=overwrites, topic="채널 설명")
@봇공지채널생성.error
async def 봇공지채널생성_error(ctx, error):
    if isinstance(error, commands.CommandInvokeError):
        await ctx.send("봇에게 채널관리 권한이 없습니다!")
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("당신은 메시지 관리권한이 없습니다!")

    if message.content.startswith("/공지"):
        ok = 0
        botc = []
        channel_info = []
        channel_type = []
        msg2 = message.content[4:] #픽사포함해서 명령어의 수에 1을 더하고 [4:] 4에 교체하세요
        if (message.author.id == ): #개발자의 id
            if not msg2:
                await message.channel.send("공지을 보내지 못했습니다! 공지을 할 내용을 입력하세요!")
            else:
                now = datetime.datetime.now()
                all_channels = app.get_all_channels()

                for channel1 in all_channels:
                    channel_type.append(str(channel1.type))  # 채널타입을 저장함
                    channel_info.append(channel1)  # 채널의 이름들을 저장함

                for i in range(len(channel_info)):  # 채널의 갯수만큼 반복합니다
                    if channel_info[i].name == "채널이름":  # (찾을 채널이름)을 가진 채널들을 타게팅합니다. 채널이름을 입력하세요
                        botc.append(int(channel_info[i].id))  # 그 타게팅한 채널들의 id을 저장합니다.'
                for i in range(len(botc)):
                    ok += 1
                    embed = discord.Embed(
                        title="공지타이틀",
                        description=msg2,
                        colour=0x7CC8FF
                    )
                    embed.set_footer(text=str(message.author) + " | 인증됨 | " + str(now.year) + "년 " + str(now.month) + "월 " + str(now.day) + "일 | " + str(now.hour) + ":" + str(now.minute) + ":" + str(now.second),icon_url=message.author.avatar_url)
                    channel = app.get_channel(botc[ok - 1])
                    await channel.send(embed=embed)
                embed = discord.Embed(
                    title="공지전송!",
                    description="공지을 전송하였습니다!\n\n전송된채널수 : {}개".format(len(botc)),
                    colour=0x7CC8FF
                )
                await message.channel.send(embed=embed)
        else:
            await message.channel.send("권한이 없습니다.")


#원리 : [접두사]봇공지채널생성을 입력하면 (채널이름), (채널설명)인 채팅방이 생성되고 [접두사]공지을 이용하면 뒤에 글을 인식하고 메시지을 보낸 유저의 id와 개발자의 id가 동일한지 확인후 봇이 접속되어있는 서버에 모든 채팅방을 불러오고 (채널이름)이라는 이름을 가진
#채팅방을 찾고 그 채팅방의 id을 botc 저장후 botc에 저장되어있는 채널에 메시지을 보냄니다.

#ok = 0
#botc = []
#channel_info = []
#channel_type = [] 은 채널정보을 다시 저번 데이터을 초기화함니다.